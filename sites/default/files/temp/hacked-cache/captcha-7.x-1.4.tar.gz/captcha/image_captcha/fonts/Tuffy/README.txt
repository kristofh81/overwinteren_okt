
This directory contains a subset (Regular and Bold) of the Tuffy typeface
created by Thatcher Ulrich (http://tulrich.com/fonts) and released in the
public domain.

Original licensing statement of the creator
-------------------------------------------
Here are my dabblings in font design. I have placed them in the Public Domain. 
This is all 100% my own work. Usage is totally unrestricted. 
If you want to make derivative works for any purpose, please go ahead.

I welcome comments & constructive criticism.

Put another way, a la PD-self (http://en.wikipedia.org/wiki/Template:PD-self):
  I, the copyright holder of this work, hereby release it into the public 
  domain. This applies worldwide.

  In case this is not legally possible,

  I grant any entity the right to use this work for any purpose, 
  without any conditions, unless such conditions are required by law.

-Thatcher Ulrich <tu@tulrich.com> http://tulrich.com
